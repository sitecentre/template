<footer>
	Copyright &copy; 2014-<?php echo date("Y"); ?> sitecentre. All rights reserved.
</footer>